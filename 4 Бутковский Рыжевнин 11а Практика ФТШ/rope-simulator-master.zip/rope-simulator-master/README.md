# Rope simulator

To start the programme run "simulator.py"

Later a pdf with physics for the simulator will be uploaded
